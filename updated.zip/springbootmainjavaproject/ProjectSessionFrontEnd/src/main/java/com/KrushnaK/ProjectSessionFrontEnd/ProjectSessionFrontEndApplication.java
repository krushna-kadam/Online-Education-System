package com.KrushnaK.ProjectSessionFrontEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSessionFrontEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectSessionFrontEndApplication.class, args);
		System.err.println("Project Running...");
	}



}