package com.KrushnaK.ProjectSessionFrontEnd.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Contact {

	public String Name;

	public String Address;

	public int MobileNo;
	@Id
	public String Email;
	
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(String name, String address, int mobileNo, String email) {
		super();
		Name = name;
		Address = address;
		MobileNo = mobileNo;
		Email = email;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public int getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(int mobileNo) {
		MobileNo = mobileNo;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	@Override
	public String toString() {
		return "Contact [Name=" + Name + ", Address=" + Address + ", MobileNo=" + MobileNo + ", Email=" + Email + "]";
	}

	
}

//	pojo  gcs+gcuf+get_set+tostr
